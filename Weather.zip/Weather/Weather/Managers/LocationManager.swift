//
//  LocationManager.swift
//  Weather
//
//  Created by Sai Kiran on 06/08/23.
//

import Foundation
import CoreLocation


class LocationManager {
    public static var shared = LocationManager()
    

    
}
